package com.example.pdfreader;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button openPdf =findViewById(R.id.button);
        openPdf.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PDFActivity2.class);
                startActivity(intent);
            }


        });
        Button csePdf =findViewById(R.id.button2);
        csePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,CseActivity2.class);
                startActivity(intent);
            }
        });

        Button civilPdf =findViewById(R.id.button3);
        civilPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CivilActivity2.class);
                startActivity(intent);
            }
        });
        Button eeePdf =findViewById(R.id.button8);
        eeePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EEEActivity2.class);
                startActivity(intent);
            }
        });
        Button iotPdf =findViewById(R.id.button6);
        iotPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, IOTActivity2.class);
                startActivity(intent);
            }
        });
        Button cicPdf =findViewById(R.id.button5);
        cicPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CICActivity2.class);
                startActivity(intent);
            }
        });
        Button itPdf =findViewById(R.id.button4);
        itPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ITActivity2.class);
                startActivity(intent);
            }
        });


    }
}